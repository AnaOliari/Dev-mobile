pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS) // Garante que repositórios do settings.gradle prevaleçam
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "HealthTrack"
include(":app")
