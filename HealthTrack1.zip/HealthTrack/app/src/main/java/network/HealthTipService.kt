package com.example.healthtrack.network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

data class HealthTip(val id: Int, val tip: String)

interface HealthTipApi {
    @GET("healthtips")
    suspend fun getDailyTip(): HealthTip
}

object HealthTipService {
    private const val BASE_URL = "https://apidadosabertos.saude.gov.br/"

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val api: HealthTipApi = retrofit.create(HealthTipApi::class.java)
}
