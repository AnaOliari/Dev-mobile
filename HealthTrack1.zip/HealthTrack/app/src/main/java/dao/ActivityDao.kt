package com.example.healthtrack.dao

import androidx.room.*
import model.Activity

@Dao
interface ActivityDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: Activity)

    @Query("SELECT * FROM activities WHERE userId = :userId")
    suspend fun getActivitiesByUserId(userId: Int): List<Activity>

    @Query("SELECT * FROM activities WHERE id = :activityId LIMIT 1")
    suspend fun getActivityById(activityId: Int): Activity?

    @Query("SELECT * FROM activities WHERE date >= :startDate")
    suspend fun getActivitiesSince(startDate: String): List<Activity>

    @Delete
    suspend fun deleteActivity(activity: Activity)

    @Update
    suspend fun updateActivity(activity: Activity)
}
