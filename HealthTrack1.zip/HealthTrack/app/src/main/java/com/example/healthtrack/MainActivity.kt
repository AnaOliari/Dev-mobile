package com.example.healthtrack

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.healthtrack.ui.*
import com.example.healthtrack.viewmodel.ActivityViewModel
import com.example.healthtrack.viewmodel.ActivityViewModelFactory


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val activityViewModel: ActivityViewModel = ViewModelProvider(
            this,
            ActivityViewModelFactory(applicationContext)
        )[ActivityViewModel::class.java]

        setContent {
            MaterialTheme {
                MainApp(activityViewModel)
            }
        }
    }
}

@Composable
fun MainApp(activityViewModel: ActivityViewModel) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "main_menu"
    ) {

        composable("main_menu") {
            MainMenu(navController)
        }


        composable("activity_list") {
            ActivityListScreen(navController = navController, activityViewModel = activityViewModel)
        }


        composable(
            route = "activity_registration/{activityId}",
            arguments = listOf(
                navArgument("activityId") {
                    type = NavType.IntType
                    defaultValue = -1 //
                }
            )
        ) { backStackEntry ->
            val activityId = backStackEntry.arguments?.getInt("activityId")
            ActivityRegistrationScreen(
                activityId = if (activityId == -1) null else activityId,
                activityViewModel = activityViewModel
            )
        }




    }
}
