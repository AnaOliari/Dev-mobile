package com.example.healthtrack.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.healthtrack.viewmodel.ActivityViewModel
import com.example.healthtrack.viewmodel.HealthTipViewModel
import androidx.compose.ui.Alignment

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    activityViewModel: ActivityViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    healthTipViewModel: HealthTipViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val navController = rememberNavController()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("HealthTrack") }
            )
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "main_menu",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("main_menu") {
                MainMenu(navController)
            }
            composable("activity_list") {
                ActivityListScreen(navController, activityViewModel)
            }
            composable(
                route = "add_activity/{activityId}",
                arguments = listOf(navArgument("activityId") {
                    nullable = true
                    type = NavType.IntType
                    defaultValue = -1
                })
            ) { backStackEntry ->
                val activityId = backStackEntry.arguments?.getInt("activityId")
                ActivityRegistrationScreen(
                    activityId = if (activityId == -1) null else activityId,
                    activityViewModel = activityViewModel
                )
            }
            composable("weekly_summary") {
                WeeklySummaryScreen(activityViewModel)
            }
            composable("health_tip") {
                HealthTipScreen(healthTipViewModel)
            }
        }
    }
}

@Composable
fun MainMenu(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "HealthTrack")

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = { navController.navigate("activity_list") }) {
            Text(text = "Ver Atividades")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("add_activity/-1") }) {
            Text(text = "Registrar Atividade")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("weekly_summary") }) {
            Text(text = "Resumo Semanal")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(onClick = { navController.navigate("health_tip") }) {
            Text(text = "Dica de Saúde")
        }
    }
}

@Composable
fun HealthTipScreen(healthTipViewModel: HealthTipViewModel) {

    Text(text = "Dica de Saúde")
}

@Composable
fun WeeklySummaryScreen(activityViewModel: ActivityViewModel) {

    Text(text = "Resumo Semanal")
}
