package com.example.healthtrack.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.healthtrack.viewmodel.ActivityViewModel
import com.example.healthtrack.viewmodel.ActivityViewModelFactory
import model.Activity

@Composable
fun RegisterActivityScreen() {
    val context = LocalContext.current
    val activityViewModel: ActivityViewModel = viewModel(factory = ActivityViewModelFactory(context))

    var type by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Registro de Atividade")

        OutlinedTextField(
            value = type,
            onValueChange = { type = it },
            label = { Text("Tipo de Atividade") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = duration,
            onValueChange = { duration = it },
            label = { Text("Duração (minutos)") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("Data (yyyy-MM-dd)") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val activity = Activity(userId = 1, type = type, duration = duration.toInt(), date = date)
                activityViewModel.insertActivity(activity)
            }
        ) {
            Text(text = "Salvar Atividade")
        }
    }
}
