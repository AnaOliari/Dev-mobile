package com.example.healthtrack.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState // Import correto
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.healthtrack.viewmodel.ActivityViewModel
import model.Activity

@Composable
fun ActivityListScreen(
    navController: NavHostController,
    activityViewModel: ActivityViewModel
) {

    val activities = activityViewModel.activities.collectAsState(initial = emptyList()).value

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        items(activities) { activity ->
            ActivityItem(
                activity = activity,
                onEditClick = {

                    navController.navigate("activity_registration/${activity.id}")
                },
                onDeleteClick = {
                    activityViewModel.deleteActivity(activity)
                }
            )
        }
    }
}

@Composable
fun ActivityItem(
    activity: Activity,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {

        Text(text = "Tipo: ${activity.type}")
        Text(text = "Duração: ${activity.duration} minutos")
        Text(text = "Data: ${activity.date}")

        Spacer(modifier = Modifier.height(8.dp))


        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = onEditClick) {
                Text("Editar")
            }

            Button(onClick = onDeleteClick) {
                Text("Excluir")
            }
        }
    }
    Spacer(modifier = Modifier.height(16.dp))
}
