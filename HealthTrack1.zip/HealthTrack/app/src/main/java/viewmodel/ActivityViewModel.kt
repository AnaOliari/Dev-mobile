package com.example.healthtrack.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.database.DatabaseInstance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import model.Activity
import java.text.SimpleDateFormat
import java.util.*

class ActivityViewModel(private val context: Context) : ViewModel() {

    private val _activities = MutableStateFlow<List<Activity>>(emptyList())
    val activities: StateFlow<List<Activity>> get() = _activities

    private val _weeklySummary = MutableStateFlow("Carregando resumo semanal...")
    val weeklySummary: StateFlow<String> get() = _weeklySummary

    init {
        loadInitialData()
    }


    private fun loadInitialData() {
        viewModelScope.launch(Dispatchers.IO) {
            val activityDao = DatabaseInstance.getDatabase(context).activityDao()


            if (activityDao.getActivitiesByUserId(1).isEmpty()) {

                activityDao.insertActivity(Activity(userId = 1, type = "Caminhada", duration = 30, date = "2023-01-01"))
                activityDao.insertActivity(Activity(userId = 1, type = "Corrida", duration = 45, date = "2023-01-02"))
            }
            loadActivities()
            updateWeeklySummary()
        }
    }


    private fun loadActivities(userId: Int = 1) {
        viewModelScope.launch(Dispatchers.IO) {
            val activityDao = DatabaseInstance.getDatabase(context).activityDao()
            val activitiesList = activityDao.getActivitiesByUserId(userId)
            _activities.update { activitiesList }
        }
    }


    fun insertActivity(activity: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            val activityDao = DatabaseInstance.getDatabase(context).activityDao()
            activityDao.insertActivity(activity)
            loadActivities(activity.userId)
            updateWeeklySummary()
        }
    }


    fun updateActivity(activity: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            val activityDao = DatabaseInstance.getDatabase(context).activityDao()
            activityDao.updateActivity(activity)
            loadActivities(activity.userId)
            updateWeeklySummary()
        }
    }


    fun deleteActivity(activity: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            val activityDao = DatabaseInstance.getDatabase(context).activityDao()
            activityDao.deleteActivity(activity)
            loadActivities(activity.userId)
            updateWeeklySummary()
        }
    }


    suspend fun getActivityById(activityId: Int): Activity? {
        val activityDao = DatabaseInstance.getDatabase(context).activityDao()
        return activityDao.getActivityById(activityId)
    }


    private fun updateWeeklySummary() {
        viewModelScope.launch(Dispatchers.IO) {
            val activityDao = DatabaseInstance.getDatabase(context).activityDao()
            val calendar = Calendar.getInstance()
            calendar.add(Calendar.DAY_OF_YEAR, -7)
            val oneWeekAgo = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.time)

            val activities = activityDao.getActivitiesSince(oneWeekAgo)
            val totalMinutes = activities.sumOf { it.duration }
            _weeklySummary.update { "Você realizou ${activities.size} atividades nesta semana, totalizando $totalMinutes minutos." }
        }
    }
}
