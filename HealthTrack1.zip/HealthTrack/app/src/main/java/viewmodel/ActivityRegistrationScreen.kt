package com.example.healthtrack.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.platform.LocalContext
import com.example.healthtrack.viewmodel.ActivityViewModel
import com.example.healthtrack.viewmodel.ActivityViewModelFactory
import model.Activity

@Composable
fun ActivityRegistrationScreen(
    activityId: Int? = null,
    activityViewModel: ActivityViewModel = viewModel(factory = ActivityViewModelFactory(LocalContext.current))
) {

    var type by remember { mutableStateOf("") }
    var duration by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }


    LaunchedEffect(activityId) {
        if (activityId != null) {
            val activity = activityViewModel.getActivityById(activityId)
            activity?.let {
                type = it.type
                duration = it.duration.toString()
                date = it.date
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = if (activityId != null) "Editar Atividade" else "Registrar Atividade")

        OutlinedTextField(
            value = type,
            onValueChange = { type = it },
            label = { Text("Tipo de Atividade") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = duration,
            onValueChange = { duration = it },
            label = { Text("Duração (minutos)") }
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("Data (yyyy-MM-dd)") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val activity = Activity(
                    userId = 1,
                    type = type,
                    duration = duration.toInt(),
                    date = date
                )
                if (activityId != null) {

                    activityViewModel.updateActivity(activity.copy(id = activityId))
                } else {

                    activityViewModel.insertActivity(activity)
                }
            }
        ) {
            Text(text = if (activityId != null) "Atualizar Atividade" else "Salvar Atividade")
        }
    }
}
