package com.example.healthtrack.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.database.DatabaseInstance
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import model.User

class UserViewModel(private val context: Context) : ViewModel() {

    fun insertUser(user: User) {
        viewModelScope.launch(Dispatchers.IO) {
            val userDao = DatabaseInstance.getDatabase(context).userDao()
            userDao.insertUser(user)
        }
    }
}
