package com.example.healthtrack.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.healthtrack.network.HealthTip
import com.example.healthtrack.network.HealthTipService
import kotlinx.coroutines.launch

class HealthTipViewModel : ViewModel() {


    val dailyTip = MutableLiveData<HealthTip>()


    fun fetchDailyTip() {
        viewModelScope.launch {
            try {

                val tip = HealthTipService.api.getDailyTip()

                dailyTip.postValue(tip)
            } catch (e: Exception) {

                e.printStackTrace()
            }
        }
    }
}
